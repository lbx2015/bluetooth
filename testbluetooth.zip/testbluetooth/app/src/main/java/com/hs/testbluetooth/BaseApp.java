package com.hs.testbluetooth;

import android.app.Application;

import com.sdwfqin.cbt.CbtManager;
import com.sdwfqin.cbt.utils.CbtConstant;

import java.util.UUID;

public class BaseApp extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        CbtManager
                .getInstance()
                // 初始化
                .init(this)
                // 是否打印相关日志
                .enableLog(true);
    }


}
